import { productDataBase } from "./script.js";
const productInfo = {};
//product validation  
function ProductValidate() {
    productInfo = {
        "ID": document.getElementById("ID").value,
        "Description": document.getElementById("Description").value,
        "Category": document.getElementById("Category").value,
        "UnitOfMeasure": document.getElementById("Measure").value,
        "Price": document.getElementById("price").value,
        "Weight": document.getElementById("Weight").value
    };

    if (productInfo.ID == "") {
        $("#ID_alert").removeClass("alert");
        return false;
    }
    if (productInfo.Description == "") {
        $("#Desc_alert").removeClass("alert");
        return false;
    }
    if (productInfo.Category == "") {
        $("#Cat_alert").removeClass("alert");
        return false;
    }
    if (productInfo.UnitOfMeasure == "") {
        $("#M_alert").removeClass("alert");
        return false;
    }
    if (productInfo.Price == "") {
        $("#Price_alert").removeClass("alert");
        return false;
    }
    
    var existingProduct = productDataBase.find(product => product.ID == productDataBase.ID)
    if (existingProduct) {
        $("#exists_alert").removeClass("alert");
        return false;
    }
    return true;
}
if (ProductValidate) {
    productDataBase.push(productInfo);
    $("#exists_alert").addClass("alert");
    $("#form")[0].reset();
    $("#upload_alert").removeClass("alert");
}
//Product error messages
$("#ID").on('input', function() {
    if (document.getElementById("ID").value != "") {
        $("#ID_alert").addClass("alert");
    }
});
$("#Description").on('input', function() {
    if (document.getElementById("Description").value != "") {
        $("#Desc_alert").addClass("alert");
    }
});
$("#Category").on('input', function() {
    if (document.getElementById("Category").value != "") {
        $("#Cat_alert").addClass("alert");
    }
});
$("#Measure").on('input', function() {
    if (document.getElementById("Measure").value != "") {
        $("#M_alert").addClass("alert");
    }
});
$("#price").on('input', function() {
    if (document.getElementById("price").value != "") {
        $("#Price_alert").addClass("alert");
    }
});


//update function
    $(document).ready(function() {
        $("#findProductBtn").click(function() {
            var searchID = $("#findID").val();
            var product = productDataBase.find(product => product.ID == searchID);

            if (product) {
                $("#updateID").val(product.ID);
                $("#updateDescription").val(product.Description);
                $("#updateCategory").val(product.Category);
                $("#updateMeasure").val(product.UnitOfMeasure);
                $("#updatePrice").val(product.Price);
                $("#updateWeight").val(product.Weight);

                $("#updateSection").show();
            } else {
                $("#display").html('<div class="alert alert-danger">Product not found!</div>');
                $("#updateSection").hide();
            }
        });
        
        $("#updateProductBtn").click(function() {
            var updateID = $("#updateID").val();
            var updatedProduct = {
                "ID": updateID,
                "Description": $("#updateDescription").val(),
                "Category": $("#updateCategory").val(),
                "UnitOfMeasure": $("#updateMeasure").val(),
                "Price": $("#updatePrice").val(),
                "Weight": $("#updateWeight").val()
            };

            var productIndex = productDataBase.findIndex(product => product.ID == updateID);
            if (productIndex >= 0) {
                productDataBase[productIndex] = updatedProduct;
                $("#display").html('<div class="alert alert-success">Product updated successfully!</div>');
            } else {
                $("#display").html('<div class="alert alert-danger">Error: Could not update the product!</div>');
            }
        });
        
        $("#searchBtn").click(function() {
            var searchTerm = $("#searchTerm").val().toLowerCase();
            var searchResults = productDataBase.filter(product => 
                product.ID.toString().includes(searchTerm) ||
                product.Category.toLowerCase().includes(searchTerm)
            );
            
            if (searchResults.length > 0) {
                var resultHTML = '<h4>Search Results:</h4>';
                searchResults.forEach(product => {
                    resultHTML += `<div>
                        <strong>ID:</strong> ${product.ID} <br>
                        <strong>Description:</strong> ${product.Description} <br>
                        <strong>Category:</strong> ${product.Category} <br>
                        <strong>Unit of Measure:</strong> ${product.UnitOfMeasure} <br>
                        <strong>Price:</strong> ${product.Price} <br>
                        <strong>Weight:</strong> ${product.Weight} <br><br>
                    </div>`;
                });
                $("#searchResults").html(resultHTML);
            } else {
                $("#searchResults").html('<div class="alert alert-danger">No products found matching your search.</div>');
            }
        });
    });
    //search products button
    $(document).ready(function() {
        
        $("#searchBtn").click(function() {
            var searchTerm = $("#searchTerm").val().toLowerCase();
            var searchResults = productDataBase.filter(product => 
                product.ID.toString().includes(searchTerm) ||
                product.Description.toLowerCase().includes(searchTerm)
            );

            if (searchResults.length > 0) {
                var resultHTML = '<h4>Search Results:</h4>';
                searchResults.forEach(product => {
                    resultHTML += `<div class="border p-2 mb-2">
                        <strong>ID:</strong> ${product.ID} <br>
                        <strong>Description:</strong> ${product.Description} <br>
                        <strong>Price:</strong> $${product.Price} <br>
                        <button class="btn btn-primary btn-sm mt-2" onclick="addToCart(${product.ID})">Add to Cart</button>
                    </div>`;
                });
                $("#searchResults").html(resultHTML);
            } else {
                $("#searchResults").html('<div class="alert alert-danger">No products found matching your search.</div>');
            }
        });
    });