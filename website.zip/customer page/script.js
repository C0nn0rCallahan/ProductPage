
export const productDataBase = [
    {
        "ID": 1,
        "Description": "central processing untit of a pc",
        "Category": "cpu",
        "UnitOfMeasure": "none",
        "Price": 399.00,
        "Weight": "none"
    },
    {
        "ID": 2,
        "Description": "Motherboard of PC",
        "Category": "motherBoard",
        "UnitOfMeasure": "none",
        "Price": 299.00,
        "Weight": "none"
    },
    {
        "ID": 3,
        "Description": "lower quality Motherboard of PC",
        "Category": "motherBoard",
        "UnitOfMeasure": "none",
        "Price": 199.00,
        "Weight": "none"
    },
]
export const customerDatabase = [
    {
        "email": "john1234@psu.edu",
        "name": "john",
        "phoneNumber": 4123890654,
        "age": 30,
        "address": "123 North Street"
    },
    {
        "email": "sarah4321@psu.edu",
        "name": "sarah",
        "phoneNumber": 4123211234,
        "age": 45,
        "address": "321 South Street"
    },
    {
        "email": "adam6789@psu.edu",
        "name": "adam",
        "phoneNumber": 4127891234,
        "age": 25,
        "address": "789 East Ave"
    }
]
export const shippingDatabase = [
    {
        "shipAddress": "123 North Street",
        "carrier": "UPS",
        "shippingMethod": "Standard"
    }
]
