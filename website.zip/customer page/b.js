import { customerDatabase } from "./script.js";
const shopperInfo = {};
  //user validation
function validate() {
    shopperInfo = {
      "email": document.getElementById("email").value,
      "name": document.getElementById("name").value,
      "phoneNumber": document.getElementById("phoneNumber").value,
      "age": document.getElementById("age").value,
      "address": document.getElementById("address").value
    };
    if (shopperInfo.email == "" || !shopperInfo.email.includes("@") || !shopperInfo.email.includes("psu.edu")) {
        $("#Email_alert").removeClass("alert");
        return false;
    }
    if (shopperInfo.name == "") {
        $("Name_alert").removeClass("alert");
        return false;
    }
    if (shopperInfo.age == "" || shopperInfo.age < 1) {
        $("#Age_alert").removeClass("alert");
        return false;
    }
    if (shopperInfo.address == "") {
        $("#Addr_alert").removeClass("alert");
        return false;
    }
    var existingUser = customerDatabase.find(customer => customer.email == shopperInfo.email);
    if (existingUser) {
        $("#userExists_alert").removeClass("alert");
        return false;
    }
    return true;

  }
  if (validate) {
    customerDatabase.push(shopperInfo);
    $("#userExists_alert").addClass("alert");
    $("#form")[0].reset();
    $("#userUpload_alert").removeClass("alert");
    event.preventDefault();
  }
  
  //User error messages
$("#email").on('input', function() {
    if (document.getElementById("email").value != "") {
        $("#Email_alert").addClass("alert");
    }
});
$("#name").on('input', function() {
    if (document.getElementById("name").value != "") {
        $("#Name_alert").addClass("alert");
    }
});
$("#age").on('input', function() {
    if (document.getElementById("age").value != "") {
        $("#Age_alert").addClass("alert");
    }
});
$("#address").on('input', function() {
    if (document.getElementById("address").value != "") {
        $("#Addr_alert").addClass("alert");
    }
});