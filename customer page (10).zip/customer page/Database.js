
//product database
const mongoose = require("mongoose");
const express = require('express');
const cors = require("cors");
const bodyParser = require('body-parser');
const app = express();
app.use(cors());
app.use(express.json());
var jsonParser = bodyParser.json();
app.use(express.urlencoded({extended: true}))
app.post("/Create", jsonParser, (req, res) => {
    const UserSchema = new mongoose.Schema({
        ID: Number,
        Description: String,
        Category: String,
        UnitOfMeasure: Number,
        Price: Number,
        Weight: Number
    });
    const product = mongoose.model('product', UserSchema);
    const product1 = new product({
        ID: req.body.ID,
        Description: req.body.Description,
        Category: req.body.Category,
        UnitOfMeasure: req.body.UnitOfMeasure,
        Price: req.body.Price,
        Weight: req.body.Weight
    })
    
    mongoose.connect("mongodb://localhost:27017/data", {
        userNewParser: true,
        useUnifiedTopology: true,
    })
    .then(() =>  {
        console.log('mongodb connected')
    })
    .catch(err => {
        console.log(err)
    })
    const connection = mongoose.connection;
    const client = connection.getClient();
    var db = client.db('data');
    db.collection('products').insertOne(product1, function(err, res) {
        
        if (err) throw err;
        //client.close();
    });
    return res.send({"result" : "passed"});
})
app.listen(3000, () => {
    console.log("server is running")
})






/*
import { MongoClient } from 'mongodb';
const uri = 'mongodb://localhost:27017';

MongoClient.connect(uri).then((client) => {
    const database = client.db('data');
    const cust = database.createCollection('customer');
    const products = database.createCollection('products');
    const ship = database.createCollection('ShippingInfo');
    
    

    database.collection('customer').insertMany(customerDatabase, function (err, res) {
        if (err) throw err;
        

    });
    database.collection('products').insertMany(productDataBase, function (err, res) {
        if (err) throw err;

    });
    database.collection('ShippingInfo').insertMany(shippingDatabase, function (err, res) {
        if (err) throw err;

    });
    database.collection('customer').aggregate([
        {
            $sort: { email: 1}
        },
        {
            $group: {
                _id: "$email",
                duplicates: { $push: "$_id" },
                count: { $sum: 1 }
            }
        },
        {
            $match: {
                count: { $gt: 1 }
            }
        },
        {
            $project: {
                _id: 0,
                name: "$_id",
                duplicates: 1
            }
        }
    ], {allowDiskUse: true}).forEach(function (doc) {
        doc.duplicates.shift();
        database.collection('customer').deleteMany({
            _id: { $in: doc.duplicates }
        });
    });
    
    
    database.collection('products').aggregate([
        {
            $sort: {ID: 1}
        },
        {
            $group: {
                _id: "$ID",
                duplicates: { $push: "$_id" },
                count: { $sum: 1 },
            }
        },
        {
            $match: {
                count: { $gt: 1 }
            }
        },
        {
            $project: {
                _id: 0,
                name: "$_id",
                duplicates: 1
            }
        }
    ], {allowDiskUse: true}).forEach(function (doc) {
        doc.duplicates.shift();
        database.collection('products').deleteMany({
            _id: { $in: doc.duplicates }
        });
    });
    
    database.collection('ShippingInfo').aggregate([
        {
            $sort: { shipAddress: 1}
        },
        {
            $group: {
                _id: "$shipAddress",
                duplicates: { $push: "$_id" },
                count: { $sum: 1 }
            }
        },
        {
            $match: {
                count: { $gt: 1 }
            }
        },
        {
            $project: {
                _id: 0,
                name: "$_id",
                duplicates: 1
            }
        }
    ], {allowDiskUse: true}).forEach(function (doc) {
        doc.duplicates.shift();
        database.collection('ShippingInfo').deleteMany({
            _id: { $in: doc.duplicates}
        });
    });



});
*/
