const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    ID: Number,
    Description: String,
    Category: String,
    UnitOfMeasure: Number,
    Price: Number,
    Weight: Number
});
const product = mongoose.model('product', UserSchema);
module.exports = product;